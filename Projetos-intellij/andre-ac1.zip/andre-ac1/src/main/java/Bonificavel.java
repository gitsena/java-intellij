public interface Bonificavel {

    Double getValorBonus();
}
